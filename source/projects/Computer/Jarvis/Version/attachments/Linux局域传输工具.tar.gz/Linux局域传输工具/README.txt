计算机可能报毒, 关闭防火墙或者加入信任白名单, 即可正常运行.

工具下载链接:

https://illusionna.readthedocs.io/zh/latest/projects/Computer/Jarvis/Version/version.html#jarvis-v1-1-2-2024-02-18-23-30-22